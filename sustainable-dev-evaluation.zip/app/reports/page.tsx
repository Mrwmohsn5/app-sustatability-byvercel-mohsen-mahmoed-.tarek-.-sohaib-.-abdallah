"use client"

import { useState } from "react"
import Link from "next/link"
import { BarChart3, Download, Filter, PieChart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ReportsPage() {
  const [selectedYear, setSelectedYear] = useState("2023")
  const [selectedCategory, setSelectedCategory] = useState("all")

  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-primary text-primary-foreground px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BarChart3 className="h-6 w-6" />
          <h1 className="text-xl font-bold">تقييم المشروعات المستدامة</h1>
        </div>
        <nav className="flex items-center gap-4">
          <Link href="/" className="text-sm font-medium hover:underline">
            الرئيسية
          </Link>
          <Link href="/projects" className="text-sm font-medium hover:underline">
            المشروعات
          </Link>
          <Link href="/reports" className="text-sm font-medium hover:underline">
            التقارير
          </Link>
          <Link href="/about" className="text-sm font-medium hover:underline">
            عن التطبيق
          </Link>
        </nav>
      </header>
      <main className="flex-1 container mx-auto p-6 rtl">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">التقارير والإحصائيات</h1>
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            تصدير التقرير
          </Button>
        </div>

        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <Card className="w-full md:w-1/3">
            <CardHeader>
              <CardTitle>تصفية النتائج</CardTitle>
              <CardDescription>اختر معايير التصفية لعرض البيانات</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">السنة</label>
                <Select value={selectedYear} onValueChange={setSelectedYear}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر السنة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2023">2023</SelectItem>
                    <SelectItem value="2022">2022</SelectItem>
                    <SelectItem value="2021">2021</SelectItem>
                    <SelectItem value="2020">2020</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">فئة المشروع</label>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر الفئة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع الفئات</SelectItem>
                    <SelectItem value="energy">الطاقة</SelectItem>
                    <SelectItem value="water">المياه</SelectItem>
                    <SelectItem value="agriculture">الزراعة</SelectItem>
                    <SelectItem value="education">التعليم</SelectItem>
                    <SelectItem value="health">الصحة</SelectItem>
                    <SelectItem value="transportation">النقل</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button className="w-full">
                <Filter className="mr-2 h-4 w-4" />
                تطبيق التصفية
              </Button>
            </CardContent>
          </Card>

          <Card className="w-full md:w-2/3">
            <CardHeader>
              <CardTitle>ملخص التأثير</CardTitle>
              <CardDescription>نظرة عامة على تأثير المشروعات في مجالات التنمية المستدامة</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="environmental">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="environmental">البيئي</TabsTrigger>
                  <TabsTrigger value="economic">الاقتصادي</TabsTrigger>
                  <TabsTrigger value="social">الاجتماعي</TabsTrigger>
                </TabsList>
                <TabsContent value="environmental" className="pt-4">
                  <div className="h-80 flex items-center justify-center bg-muted rounded-md">
                    <div className="text-center">
                      <PieChart className="h-16 w-16 mx-auto text-muted-foreground" />
                      <p className="mt-2 text-sm text-muted-foreground">رسم بياني للتأثير البيئي</p>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="economic" className="pt-4">
                  <div className="h-80 flex items-center justify-center bg-muted rounded-md">
                    <div className="text-center">
                      <BarChart3 className="h-16 w-16 mx-auto text-muted-foreground" />
                      <p className="mt-2 text-sm text-muted-foreground">رسم بياني للتأثير الاقتصادي</p>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="social" className="pt-4">
                  <div className="h-80 flex items-center justify-center bg-muted rounded-md">
                    <div className="text-center">
                      <BarChart3 className="h-16 w-16 mx-auto text-muted-foreground" />
                      <p className="mt-2 text-sm text-muted-foreground">رسم بياني للتأثير الاجتماعي</p>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>التأثير البيئي</CardTitle>
              <CardDescription>تحليل التأثير البيئي للمشروعات</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-60 flex items-center justify-center bg-muted rounded-md">
                <div className="text-center">
                  <PieChart className="h-12 w-12 mx-auto text-muted-foreground" />
                  <p className="mt-2 text-sm text-muted-foreground">رسم بياني للتأثير البيئي</p>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span>خفض انبعاثات الكربون</span>
                  <span className="font-medium">75%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>توفير المياه</span>
                  <span className="font-medium">60%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>إعادة التدوير</span>
                  <span className="font-medium">45%</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>التأثير الاقتصادي</CardTitle>
              <CardDescription>تحليل التأثير الاقتصادي للمشروعات</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-60 flex items-center justify-center bg-muted rounded-md">
                <div className="text-center">
                  <BarChart3 className="h-12 w-12 mx-auto text-muted-foreground" />
                  <p className="mt-2 text-sm text-muted-foreground">رسم بياني للتأثير الاقتصادي</p>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span>خلق فرص عمل</span>
                  <span className="font-medium">65%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>زيادة الإنتاجية</span>
                  <span className="font-medium">70%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>تقليل التكاليف</span>
                  <span className="font-medium">55%</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>التأثير الاجتماعي</CardTitle>
              <CardDescription>تحليل التأثير الاجتماعي للمشروعات</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-60 flex items-center justify-center bg-muted rounded-md">
                <div className="text-center">
                  <BarChart3 className="h-12 w-12 mx-auto text-muted-foreground" />
                  <p className="mt-2 text-sm text-muted-foreground">رسم بياني للتأثير الاجتماعي</p>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span>تحسين جودة الحياة</span>
                  <span className="font-medium">80%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>تعزيز المساواة</span>
                  <span className="font-medium">50%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>تحسين الخدمات</span>
                  <span className="font-medium">65%</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <footer className="bg-muted py-6 px-6 text-center">
        <p className="text-sm text-muted-foreground">
          تطبيق تقييم المشروعات وأثر التكنولوجيا الحديثة في تعزيز التنمية المستدامة © {new Date().getFullYear()}
        </p>
      </footer>
    </div>
  )
}
