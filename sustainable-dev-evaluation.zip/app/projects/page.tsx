import Link from "next/link"
import { ArrowUpDown, BarChart3, Eye, Plus, Search, Tag } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"

export default function ProjectsPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-primary text-primary-foreground px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BarChart3 className="h-6 w-6" />
          <h1 className="text-xl font-bold">تقييم المشروعات المستدامة</h1>
        </div>
        <nav className="flex items-center gap-4">
          <Link href="/" className="text-sm font-medium hover:underline">
            الرئيسية
          </Link>
          <Link href="/projects" className="text-sm font-medium hover:underline">
            المشروعات
          </Link>
          <Link href="/reports" className="text-sm font-medium hover:underline">
            التقارير
          </Link>
          <Link href="/about" className="text-sm font-medium hover:underline">
            عن التطبيق
          </Link>
        </nav>
      </header>
      <main className="flex-1 container mx-auto p-6 rtl">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">المشروعات</h1>
          <Button asChild>
            <Link href="/projects/new">
              <Plus className="mr-2 h-4 w-4" />
              إضافة مشروع جديد
            </Link>
          </Button>
        </div>

        <div className="flex items-center space-x-2 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input type="search" placeholder="البحث عن مشروع..." className="pl-8 w-full" />
          </div>
          <Button variant="outline" size="icon">
            <ArrowUpDown className="h-4 w-4" />
            <span className="sr-only">ترتيب</span>
          </Button>
          <Button variant="outline" size="icon">
            <Tag className="h-4 w-4" />
            <span className="sr-only">تصفية</span>
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <Card key={project.id}>
              <CardHeader>
                <CardTitle>{project.name}</CardTitle>
                <CardDescription>{project.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>التأثير البيئي</span>
                      <span className="font-medium">{project.environmentalImpact}%</span>
                    </div>
                    <Progress value={project.environmentalImpact} />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>التأثير الاقتصادي</span>
                      <span className="font-medium">{project.economicImpact}%</span>
                    </div>
                    <Progress value={project.economicImpact} />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>التأثير الاجتماعي</span>
                      <span className="font-medium">{project.socialImpact}%</span>
                    </div>
                    <Progress value={project.socialImpact} />
                  </div>
                  <div className="flex flex-wrap gap-2 mt-4">
                    {project.technologies.map((tech) => (
                      <Badge key={tech} variant="outline">
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="ghost" className="w-full" asChild>
                  <Link href={`/projects/${project.id}`}>
                    <Eye className="mr-2 h-4 w-4" />
                    عرض التفاصيل
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </main>
      <footer className="bg-muted py-6 px-6 text-center">
        <p className="text-sm text-muted-foreground">
          تطبيق تقييم المشروعات وأثر التكنولوجيا الحديثة في تعزيز التنمية المستدامة © {new Date().getFullYear()}
        </p>
      </footer>
    </div>
  )
}

const projects = [
  {
    id: 1,
    name: "مشروع الطاقة الشمسية المتجددة",
    description: "مشروع لتوليد الطاقة الكهربائية باستخدام الألواح الشمسية في المناطق النائية",
    environmentalImpact: 85,
    economicImpact: 70,
    socialImpact: 65,
    technologies: ["الطاقة الشمسية", "الشبكات الذكية", "تخزين الطاقة"],
  },
  {
    id: 2,
    name: "نظام الري الذكي",
    description: "نظام ري ذكي يعتمد على إنترنت الأشياء لتوفير المياه وزيادة إنتاجية المحاصيل",
    environmentalImpact: 75,
    economicImpact: 80,
    socialImpact: 60,
    technologies: ["إنترنت الأشياء", "الذكاء الاصطناعي", "أجهزة استشعار"],
  },
  {
    id: 3,
    name: "منصة التعليم الإلكتروني",
    description: "منصة تعليمية تفاعلية لتوفير التعليم عن بعد في المناطق المحرومة",
    environmentalImpact: 40,
    economicImpact: 65,
    socialImpact: 90,
    technologies: ["التعلم الإلكتروني", "الواقع الافتراضي", "الحوسبة السحابية"],
  },
  {
    id: 4,
    name: "نظام إدارة النفايات الذكي",
    description: "نظام متكامل لإدارة النفايات وإعادة تدويرها باستخدام التكنولوجيا الحديثة",
    environmentalImpact: 90,
    economicImpact: 60,
    socialImpact: 70,
    technologies: ["إنترنت الأشياء", "تحليل البيانات", "الروبوتات"],
  },
  {
    id: 5,
    name: "منصة الزراعة المستدامة",
    description: "منصة لدعم المزارعين وتحسين الإنتاج الزراعي باستخدام التقنيات الحديثة",
    environmentalImpact: 80,
    economicImpact: 75,
    socialImpact: 85,
    technologies: ["الزراعة الدقيقة", "الذكاء الاصطناعي", "أجهزة استشعار"],
  },
  {
    id: 6,
    name: "نظام النقل الذكي",
    description: "نظام متكامل لإدارة حركة المرور وتقليل الازدحام وخفض الانبعاثات",
    environmentalImpact: 70,
    economicImpact: 65,
    socialImpact: 75,
    technologies: ["إنترنت الأشياء", "تحليل البيانات", "الذكاء الاصطناعي"],
  },
]
