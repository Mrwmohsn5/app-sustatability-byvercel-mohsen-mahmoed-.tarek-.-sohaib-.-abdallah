"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, BarChart3, Info, Save } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"

export default function NewProjectPage() {
  const [environmentalImpact, setEnvironmentalImpact] = useState(50)
  const [economicImpact, setEconomicImpact] = useState(50)
  const [socialImpact, setSocialImpact] = useState(50)

  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-primary text-primary-foreground px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BarChart3 className="h-6 w-6" />
          <h1 className="text-xl font-bold">تقييم المشروعات المستدامة</h1>
        </div>
        <nav className="flex items-center gap-4">
          <Link href="/" className="text-sm font-medium hover:underline">
            الرئيسية
          </Link>
          <Link href="/projects" className="text-sm font-medium hover:underline">
            المشروعات
          </Link>
          <Link href="/reports" className="text-sm font-medium hover:underline">
            التقارير
          </Link>
          <Link href="/about" className="text-sm font-medium hover:underline">
            عن التطبيق
          </Link>
        </nav>
      </header>
      <main className="flex-1 container mx-auto p-6 rtl">
        <div className="flex items-center gap-2 mb-6">
          <Button variant="outline" size="icon" asChild>
            <Link href="/projects">
              <ArrowLeft className="h-4 w-4" />
              <span className="sr-only">العودة</span>
            </Link>
          </Button>
          <h1 className="text-3xl font-bold">إضافة مشروع جديد</h1>
        </div>

        <Tabs defaultValue="basic" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="basic">معلومات أساسية</TabsTrigger>
            <TabsTrigger value="impact">تقييم الأثر</TabsTrigger>
            <TabsTrigger value="technology">التكنولوجيا المستخدمة</TabsTrigger>
          </TabsList>
          <TabsContent value="basic">
            <Card>
              <CardHeader>
                <CardTitle>المعلومات الأساسية</CardTitle>
                <CardDescription>أدخل المعلومات الأساسية للمشروع</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid w-full items-center gap-2">
                  <Label htmlFor="project-name">اسم المشروع</Label>
                  <Input id="project-name" placeholder="أدخل اسم المشروع" />
                </div>
                <div className="grid w-full items-center gap-2">
                  <Label htmlFor="project-description">وصف المشروع</Label>
                  <Textarea id="project-description" placeholder="أدخل وصفاً مختصراً للمشروع" rows={4} />
                </div>
                <div className="grid w-full items-center gap-2">
                  <Label htmlFor="project-location">موقع المشروع</Label>
                  <Input id="project-location" placeholder="أدخل موقع المشروع" />
                </div>
                <div className="grid w-full items-center gap-2">
                  <Label htmlFor="project-budget">الميزانية التقديرية (بالدولار الأمريكي)</Label>
                  <Input id="project-budget" type="number" placeholder="أدخل الميزانية التقديرية" />
                </div>
                <div className="grid w-full items-center gap-2">
                  <Label htmlFor="project-duration">مدة المشروع (بالأشهر)</Label>
                  <Input id="project-duration" type="number" placeholder="أدخل مدة المشروع" />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="impact">
            <Card>
              <CardHeader>
                <CardTitle>تقييم الأثر</CardTitle>
                <CardDescription>قيّم أثر المشروع على الجوانب المختلفة للتنمية المستدامة</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>
                      التأثير البيئي
                      <Button variant="ghost" size="icon" className="ml-1">
                        <Info className="h-4 w-4" />
                      </Button>
                    </Label>
                    <span className="font-medium">{environmentalImpact}%</span>
                  </div>
                  <Slider
                    value={[environmentalImpact]}
                    min={0}
                    max={100}
                    step={1}
                    onValueChange={(value) => setEnvironmentalImpact(value[0])}
                  />
                  <div className="text-sm text-muted-foreground">
                    يقيس مدى مساهمة المشروع في الحفاظ على البيئة وتقليل التلوث واستخدام الموارد بشكل مستدام.
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>
                      التأثير الاقتصادي
                      <Button variant="ghost" size="icon" className="ml-1">
                        <Info className="h-4 w-4" />
                      </Button>
                    </Label>
                    <span className="font-medium">{economicImpact}%</span>
                  </div>
                  <Slider
                    value={[economicImpact]}
                    min={0}
                    max={100}
                    step={1}
                    onValueChange={(value) => setEconomicImpact(value[0])}
                  />
                  <div className="text-sm text-muted-foreground">
                    يقيس مدى مساهمة المشروع في تحسين الاقتصاد المحلي وخلق فرص عمل وتحقيق عائد استثماري.
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>
                      التأثير الاجتماعي
                      <Button variant="ghost" size="icon" className="ml-1">
                        <Info className="h-4 w-4" />
                      </Button>
                    </Label>
                    <span className="font-medium">{socialImpact}%</span>
                  </div>
                  <Slider
                    value={[socialImpact]}
                    min={0}
                    max={100}
                    step={1}
                    onValueChange={(value) => setSocialImpact(value[0])}
                  />
                  <div className="text-sm text-muted-foreground">
                    يقيس مدى مساهمة المشروع في تحسين جودة حياة المجتمع وتعزيز المساواة والشمول الاجتماعي.
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="technology">
            <Card>
              <CardHeader>
                <CardTitle>التكنولوجيا المستخدمة</CardTitle>
                <CardDescription>
                  حدد التقنيات المستخدمة في المشروع وكيفية مساهمتها في التنمية المستدامة
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid w-full items-center gap-2">
                  <Label htmlFor="tech-category">فئة التكنولوجيا الرئيسية</Label>
                  <Select>
                    <SelectTrigger id="tech-category">
                      <SelectValue placeholder="اختر فئة التكنولوجيا" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="renewable-energy">الطاقة المتجددة</SelectItem>
                      <SelectItem value="iot">إنترنت الأشياء</SelectItem>
                      <SelectItem value="ai">الذكاء الاصطناعي</SelectItem>
                      <SelectItem value="blockchain">تقنية البلوكتشين</SelectItem>
                      <SelectItem value="cloud">الحوسبة السحابية</SelectItem>
                      <SelectItem value="mobile">تطبيقات الهاتف المحمول</SelectItem>
                      <SelectItem value="other">أخرى</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-4">
                  <Label>التقنيات المستخدمة</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Checkbox id="tech-solar" />
                      <Label htmlFor="tech-solar">الطاقة الشمسية</Label>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Checkbox id="tech-wind" />
                      <Label htmlFor="tech-wind">طاقة الرياح</Label>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Checkbox id="tech-iot" />
                      <Label htmlFor="tech-iot">إنترنت الأشياء</Label>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Checkbox id="tech-ai" />
                      <Label htmlFor="tech-ai">الذكاء الاصطناعي</Label>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Checkbox id="tech-blockchain" />
                      <Label htmlFor="tech-blockchain">البلوكتشين</Label>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Checkbox id="tech-cloud" />
                      <Label htmlFor="tech-cloud">الحوسبة السحابية</Label>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Checkbox id="tech-mobile" />
                      <Label htmlFor="tech-mobile">تطبيقات الهاتف المحمول</Label>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Checkbox id="tech-sensors" />
                      <Label htmlFor="tech-sensors">أجهزة الاستشعار</Label>
                    </div>
                  </div>
                </div>

                <div className="grid w-full items-center gap-2">
                  <Label htmlFor="tech-description">وصف استخدام التكنولوجيا</Label>
                  <Textarea
                    id="tech-description"
                    placeholder="اشرح كيف تساهم التكنولوجيا المستخدمة في تحقيق أهداف التنمية المستدامة"
                    rows={4}
                  />
                </div>

                <div className="grid w-full items-center gap-2">
                  <Label htmlFor="tech-innovation">الابتكار التكنولوجي</Label>
                  <Textarea
                    id="tech-innovation"
                    placeholder="اشرح الجوانب المبتكرة في استخدام التكنولوجيا في المشروع"
                    rows={4}
                  />
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline">إلغاء</Button>
                <Button>
                  <Save className="mr-2 h-4 w-4" />
                  حفظ المشروع
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      <footer className="bg-muted py-6 px-6 text-center">
        <p className="text-sm text-muted-foreground">
          تطبيق تقييم المشروعات وأثر التكنولوجيا الحديثة في تعزيز التنمية المستدامة © {new Date().getFullYear()}
        </p>
      </footer>
    </div>
  )
}
