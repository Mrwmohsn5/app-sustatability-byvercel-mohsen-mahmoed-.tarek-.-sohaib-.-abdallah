import Link from "next/link"
import { ArrowRight, BarChart3, FileText, Home, PieChart, Plus } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-primary text-primary-foreground px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BarChart3 className="h-6 w-6" />
          <h1 className="text-xl font-bold">تقييم المشروعات المستدامة</h1>
        </div>
        <nav className="flex items-center gap-4">
          <Link href="/" className="text-sm font-medium hover:underline">
            الرئيسية
          </Link>
          <Link href="/projects" className="text-sm font-medium hover:underline">
            المشروعات
          </Link>
          <Link href="/reports" className="text-sm font-medium hover:underline">
            التقارير
          </Link>
          <Link href="/about" className="text-sm font-medium hover:underline">
            عن التطبيق
          </Link>
        </nav>
      </header>
      <main className="flex-1 container mx-auto p-6 rtl">
        <section className="mb-10 text-center">
          <h1 className="text-4xl font-bold mb-4">تطبيق تقييم المشروعات وأثر التكنولوجيا الحديثة</h1>
          <p className="text-xl text-muted-foreground mb-6">
            منصة متكاملة لتقييم أثر التكنولوجيا الحديثة في تعزيز التنمية المستدامة
          </p>
          <div className="flex justify-center gap-4">
            <Button asChild size="lg">
              <Link href="/projects/new">
                إضافة مشروع جديد
                <Plus className="mr-2 h-4 w-4" />
              </Link>
            </Button>
            <Button variant="outline" size="lg" asChild>
              <Link href="/projects">
                استعراض المشروعات
                <ArrowRight className="mr-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Home className="h-5 w-5" />
                <span>لوحة التحكم</span>
              </CardTitle>
              <CardDescription>نظرة عامة على المشروعات والتقييمات</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-40 flex items-center justify-center bg-muted rounded-md">
                <PieChart className="h-16 w-16 text-muted-foreground" />
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" className="w-full" asChild>
                <Link href="/dashboard">الذهاب إلى لوحة التحكم</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                <span>تقييم المشروعات</span>
              </CardTitle>
              <CardDescription>إضافة وتقييم المشروعات الجديدة</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-40 flex items-center justify-center bg-muted rounded-md">
                <Plus className="h-16 w-16 text-muted-foreground" />
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" className="w-full" asChild>
                <Link href="/projects/new">إضافة مشروع جديد</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                <span>التقارير والإحصائيات</span>
              </CardTitle>
              <CardDescription>تحليل بيانات المشروعات وتأثيرها</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-40 flex items-center justify-center bg-muted rounded-md">
                <BarChart3 className="h-16 w-16 text-muted-foreground" />
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" className="w-full" asChild>
                <Link href="/reports">عرض التقارير</Link>
              </Button>
            </CardFooter>
          </Card>
        </section>

        <section className="mb-10">
          <h2 className="text-2xl font-bold mb-4 text-right">أهداف التنمية المستدامة</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {sustainableDevelopmentGoals.map((goal) => (
              <div key={goal.id} className="p-4 border rounded-lg text-center hover:bg-muted transition-colors">
                <div
                  className="w-16 h-16 mx-auto mb-2 rounded-full flex items-center justify-center"
                  style={{ backgroundColor: goal.color }}
                >
                  <span className="text-white font-bold">{goal.id}</span>
                </div>
                <h3 className="font-medium text-sm">{goal.name}</h3>
              </div>
            ))}
          </div>
        </section>
      </main>
      <footer className="bg-muted py-6 px-6 text-center">
        <p className="text-sm text-muted-foreground">
          تطبيق تقييم المشروعات وأثر التكنولوجيا الحديثة في تعزيز التنمية المستدامة © {new Date().getFullYear()}
        </p>
      </footer>
    </div>
  )
}

const sustainableDevelopmentGoals = [
  { id: 1, name: "القضاء على الفقر", color: "#E5243B" },
  { id: 2, name: "القضاء التام على الجوع", color: "#DDA63A" },
  { id: 3, name: "الصحة الجيدة والرفاه", color: "#4C9F38" },
  { id: 4, name: "التعليم الجيد", color: "#C5192D" },
  { id: 5, name: "المساواة بين الجنسين", color: "#FF3A21" },
  { id: 6, name: "المياه النظيفة والنظافة الصحية", color: "#26BDE2" },
  { id: 7, name: "طاقة نظيفة وبأسعار معقولة", color: "#FCC30B" },
  { id: 8, name: "العمل اللائق ونمو الاقتصاد", color: "#A21942" },
]
